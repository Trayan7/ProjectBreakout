package breakout;

import acm.program.*;
import acm.graphics.*;
import java.awt.Color;
import java.sql.Array;
import java.util.ArrayList;

/*
 * There are 2 velocity values. One global one in Model and one in AnimatedBall.
 * Don't remove Bricks manually. They have hitPoints and update() removes them if HP <= 0.
 * 
 * 
 * To-do:
 * 
 * MANDATORY
 * - write comments
 * - implement losing conditions
 * 
 * DESIREABLE
 * - improve interface
 * - multiple levels
 * - multiple lives
 * - pause function
 * - high score board
 * 
 * OPTIONAL
 * - implement punishing mechanics (e.g. balls get faster)
 * - implement reward mechanics (e.g. power ups, combo multiplier, fancy effects)
 * - multiple hits / strong balls 
 * - different modes/themes
 * 
 */

public class FunctionalityTest extends GraphicsProgram {

	/* Debugging */
	/* Debugging */

	// private Timer timer = new Timer(Model.getCycle() / 2.0);
	private Timer timer = Model.getTimer2();
	private int score;
	ArrayList<Brick> level = new ArrayList<Brick>();

	public void run() {

		setSize(Model.getWidth(), Model.getHeight());

		GLabel scoreLabel = new GLabel("", 10, 20);
		add(scoreLabel);

		// "Level generator"
		Level levelO = new Level(5, 5);
		ArrayList<Brick> level = levelO.getCurrentLevel();
		update(level);

		// Create ball
		AnimatedBall curBall = Model.getRedBall();
		add(curBall, Model.getBallStart());
		Thread curBallThread = new Thread(curBall);
		curBallThread.start();

		// Create paddle
		AnimatedPaddle curPaddle = Model.getPaddle();
		add(curPaddle, Model.getPaddleStart());
		Thread curPaddleThread = new Thread(curPaddle);
		curPaddleThread.start();

		// Starting screen
		GLabel startMessage = new GLabel("Click to start Breakout!");
		startMessage.setLocation(Model.getWidth() / 2 - startMessage.getWidth() / 2, Model.getHeight() / 2 + 10);
		add(startMessage);
		waitForClick();
		remove(startMessage);

		// Bounding walls
		add(Model.getLeft());
		add(Model.getRight());
		add(Model.getUp());

		//Temporary fix. Debugging required.
		curBall.setPixelPerTick(5);

		while (curBallThread.isAlive() && !Model.isLost() && !Model.isWon() && level.size() >= 1
				&& !Model.isPause()) {

			if (wouldCollideWith(curBall) != null) {
				double calcDirection = calculateDirection(curBall, wouldCollideWith(curBall));
				timer.pause();
				curBall.setDirection(calcDirection);

				scoreLabel.setLabel("Score: " + score);

			}
			update(level);
			timer.pause();
		}

		// Game over screen (View/controller)
		GLabel gameOver = Model.isLost()? new GLabel("GAME OVER!") : new GLabel("YOU WON!");
		GLabel highScore = new GLabel("Your score is: " + score + "!");
		gameOver.setLocation(Model.getWidth() / 2 - gameOver.getWidth(), Model.getHeight() / 2);
		highScore.setLocation(Model.getWidth() / 2 - highScore.getWidth(), Model.getHeight() / 2 - 30);
		add(gameOver);
		add(highScore);

	}

	private Object wouldCollideWith(AnimatedBall curBall) {

		// Wrong starting point and anti-clockwise rotation of direction.
		// double deltaX = Math.sin(Math.toRadians(curBall.getDirection())) *
		// AnimatedBall.getDelta();
		// double deltaY = Math.cos(Math.toRadians(curBall.getDirection())) *
		// AnimatedBall.getDelta();

		double ballX = curBall.getX();
		double ballY = curBall.getY();
		double size = AnimatedBall.getBallSize();
		double deltaX = Math.cos(Math.toRadians(curBall.getDirection())) * AnimatedBall.getPixelPerTick();
		double deltaY = -Math.sin(Math.toRadians(curBall.getDirection())) * AnimatedBall.getPixelPerTick();

		return collisionObject(ballX, ballY, size, deltaX, deltaY);

	}

	private double calculateDirection(AnimatedBall redBall, Object elementAt) {
		double newDirection = redBall.getDirection();
		if (elementAt instanceof AnimatedPaddle) {
			newDirection = paddleReflect(redBall, (AnimatedPaddle) elementAt);
		} else if (elementAt instanceof GRect) {
			newDirection = reflectUniversal(redBall, (GObject) elementAt);
			println(elementAt);
			if (elementAt instanceof Brick) {
				((Brick) elementAt).setHitPoints(((Brick) elementAt).getHitPoints() - redBall.getHit());
				update(level);
			}
		} else {
			assert false : "No legal collision object handed to calculate new direction.";
		}

		assert newDirection == redBall.getDirection() : "No new direction set.";
		return newDirection;
	}

	private double paddleReflect(AnimatedBall ball, AnimatedPaddle paddle) {
		double transformationFactor = 0.7;
		double direction = ball.getDirection() % 360;
		if (direction < 0) {
			direction += 360;
		}

		double deltaDistance = (ball.getX() + ball.getWidth() / 2 - paddle.getX() - paddle.getWidth() / 2);
		double deltaMax = (paddle.getWidth() / 2.0 + ball.getWidth());
		println(deltaDistance / deltaMax);

		double newDirection;
		if (direction <= 180) {
			newDirection = 180 - direction;
		} else {
			newDirection = 360 - direction;
		}
		newDirection = newDirection - (deltaDistance / deltaMax * newDirection * transformationFactor);
		return newDirection;
	}

	

	private double reflectUniversal(AnimatedBall ball, GObject col) {
		double direction = ball.getDirection();
		double newDirection;

		double ballX = ball.getX();
		double ballY = ball.getY();
		double size = AnimatedBall.getBallSize();
		double deltaX = Math.cos(Math.toRadians(180 - direction)) * AnimatedBall.getDelta();
		double deltaY = -Math.sin(Math.toRadians(180 - direction)) * AnimatedBall.getDelta();

		if (collisionObject(ballX, ballY, size, deltaX, deltaY) != null) {
			newDirection = 360 - direction;
		} else {
			newDirection = 180 - direction;
		}
		return newDirection;
	}

	public void update(ArrayList<Brick> level) {
		for (int j = 0; j < level.size(); j++) {
			if (level.get(j).getHitPoints() <= 0) {
				score += level.get(j).getPoints();
				remove(level.get(j));
				level.remove(j);
				break;
			}
		}
		for (int i = 0; i < level.size(); i++) {
			add(level.get(i));
		}
	}

	private Object collisionObject(double ballX, double ballY, double size, double deltaX, double deltaY) {
		Object collisionObject = null;
		// bottom right
		collisionObject = getElementAt(deltaX + ballX + size, deltaY + ballY + size);
		if (collisionObject != null && !(collisionObject instanceof AnimatedBall)) {
			return collisionObject;
		} else {
		}
		// bottom left
		collisionObject = getElementAt(deltaX + ballX, deltaY + ballY + size);
		if (collisionObject != null && !(collisionObject instanceof AnimatedBall)) {
			return collisionObject;
		} else {
		}
		// upper left
		collisionObject = getElementAt(deltaX + ballX, deltaY + ballY);
		if (collisionObject != null && !(collisionObject instanceof AnimatedBall)) {
			return collisionObject;
		} else {
		}
		// upper right
		collisionObject = getElementAt(deltaX + ballX + size, deltaY + ballY);
		if (collisionObject != null && !(collisionObject instanceof AnimatedBall)) {
			return collisionObject;
		} else {
		}
		return null;
	}

}