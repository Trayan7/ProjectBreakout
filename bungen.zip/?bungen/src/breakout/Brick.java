package breakout;

import acm.graphics.GRect;
//	import acm.program.*;
	
	
	public class Brick extends GRect{

		/* Private instance variables */
		private static double height = 40;
		private static double width = 20;
		private int points = 5;
		private int hitPoints = 1;
		
		/* Creates a new AnimatedRectangle of the specified size */
		public Brick(double x, double y) {
			super(x, y, height, width);
		}
		
		public static double getBrickHeight() {
			return height;
		}
		
		public static double getBrickWidth() {
			return width;
		}

		public static void setBrickWidth(double width) {
			Brick.height = width;
		}
		
		public static void setBrickHeight(double height) {
			Brick.width = height;
		}

		public int getPoints() {
			return points;
		}

		public void setPoints(int points) {
			this.points = points;
		}

		public int getHitPoints() {
			return hitPoints;
		}

		public void setHitPoints(int hitPoints) {
			this.hitPoints = hitPoints;
		}
	}