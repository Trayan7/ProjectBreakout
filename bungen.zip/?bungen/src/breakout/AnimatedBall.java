package breakout;

import acm.graphics.*;

public class AnimatedBall extends GOval implements Runnable{

	/* Private instance variables */
	private double direction = 90;
	private Timer timer = new Timer(Model.getCycle());
	private static int size = 5;
	private static double pixelPerTick = Model.getPixelPerTick();
	private int hit = 1; //damage inflicted upon hitting a brick
	
	/* Creates a new AnimatedBall of the specified size */
	public AnimatedBall(double size) {
		super(size,size);
	}
	
	/* Runs when this object is started to animate the ball */
	// Debugging shows that the ball moves before there is 
	
	public void run() {
		while(!Model.isPause()){
			movePolar(pixelPerTick, direction);
			timer.pause();
		}
	}
	
	public void setDirection(double dir){
		this.direction = dir;
	}

	public double getDirection(){
		return direction;
	}

	public static double getDelta() {
		return pixelPerTick;
	}
	
	public static int getBallSize() {
		return size;
	}

	public static void setSize(int size) {
		AnimatedBall.size = size;
	}

	public void setPixelPerTick(double vel){
		AnimatedBall.pixelPerTick = vel;
	}

	public static double getPixelPerTick(){
		return AnimatedBall.pixelPerTick;
	}
	
	public int getHit(){
		return hit;
	}
	
	public void setHit(int val){
		this.hit = val;
	}
	
	
//	public double getY() {
//		return y;
//	}
//
//	public void setY(double y) {
//		this.y = y;
//	}
//
//	public double getX() {
//		return x;
//	}
//
//	public void setX(double x) {
//		this.x = x;
//	}
	
	
	
}
