package breakout;

import java.awt.Color;
import java.util.ArrayList;

import acm.graphics.*;

public class Level {

	Color c[] = { new Color(137, 85, 255), new Color(77, 200, 232), new Color(98, 255, 105), new Color(232, 215, 77),
			new Color(255, 145, 65) };

	private ArrayList<Brick> currentLevel = new ArrayList<Brick>();

	Level(int columns, int rows) {
		for (int i = 0; i < columns; i++) {
			for (int j = 0; j < rows; j++) {
				Brick brick = new Brick((Model.getWidth() - 15) / columns * j + 15,
						Model.getHeight() / 3 / rows * i + 40);
				Color brickColor = c[i];
				brick.setColor(brickColor);
				brick.setFilled(true);
				currentLevel.add(brick);
			}
		}
	}
	
	public ArrayList<Brick> getCurrentLevel(){
		return currentLevel;
	}
	
}
